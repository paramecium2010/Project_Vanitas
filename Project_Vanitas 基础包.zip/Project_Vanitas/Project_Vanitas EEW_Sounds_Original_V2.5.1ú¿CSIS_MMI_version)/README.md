eew cancel 紧急地震速报取消时播放
eew level0 推定烈度小于5时播放
eew level1 推定烈度大于等于5且小于7时播放（长周期地震动1、2级播放）
eew level2 推定烈度大于等于8时播放（长周期地震动3、4级播放）
eew update 速报更新时播放
eew update final 发布最终报时播放
auto report 发布自动测定时播放
report 发布正式测定时播放
report cancel 地震情报取消时播放
csis 按照推定最大烈度播放
PGA 按照PGA进行播放（虽说现在没有就是了）
tsunami caution 发布海啸蓝色、黄色预警时播放（在海啸情报更新时按照等级播放）
tsunami warning 发布海啸橙色、红色预警时播放（在海啸情报更新时按照等级播放）
tsunami observation 发布海啸观测情报时播放
tsunami cancel 海啸情报取消时播放