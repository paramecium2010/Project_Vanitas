eew cancel 紧急地震速报取消时播放
eew level0 推定震度小于3时播放
eew level1 推定震度大于等于3且小于5-时播放（长周期地震动1、2级播放）
eew level2 推定震度大于等于5-时播放（长周期地震动3、4级播放）
eew update 速报更新时播放
eew update final 发布最终报时播放
intensity report 发布震度速报时播放
rapid report 发布震源速报时播放
report 发布震度·震源情报时播放、
report cancel 地震情报取消时播放
shindo 按照实测最大震度播放
PGA 按照实测PGA进行播放
tsunami caution 发布海啸注意报时播放（在海啸情报更新时按照等级播放）
tsunami warning 发布海啸警报、大海啸警报时播放（在海啸情报更新时按照等级播放）
tsunami observation 发布海啸观测情报时播放
tsunami cancel 海啸情报取消时播放